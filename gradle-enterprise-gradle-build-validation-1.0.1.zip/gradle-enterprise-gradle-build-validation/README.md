Gradle Enterprise Build Validation Scripts
==========================================

Details and instructions on how to use the build validation scripts can be found here:
https://github.com/gradle/gradle-enterprise-build-validation-scripts

The Gradle Enterprise Build Validation scripts are open-source software released under the Apache 2.0 License:
https://www.apache.org/licenses/LICENSE-2.0.html
